<!-- GRANT UPDATE ON *.* TO readeDR@'%' IDENTIFIED BY 'Pev_Congo@@DB242'; -->

<!DOCTYPE html>
<html lang="fr" ng-app="msrcPortal">

<head>

        <!-- <meta http-equiv="Refresh" CONTENT="650;URL=https://lnsp-cg.org/session_in.php"> -->
    <meta charset="UTF-8" />
    <meta name="viewport" content="widtd=device-widtd, initial-scale=1.0">
    <title ng-bind="windowTitle">TEST ANTIGENIQUE</title>

    <link rel="stylesheet" type="text/css" href="./csjs/css.css">
    <link rel="stylesheet" type="text/css"
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/js/bootstrap.bundle.min.js"
        crossorigin="anonymous">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js" crossorigin="anonymous">
    </script>

</head>

<body style="
        background: #20262E;
        padding: 2%;
        /* margin: auto;
        font-family: Helvetica; */

        background:
            linear-gradient(27deg, #151515 5px, transparent 5px) 0 5px,
            linear-gradient(207deg, #151515 5px, transparent 5px) 10px 0px,
            linear-gradient(27deg, #222 5px, transparent 5px) 0px 10px,
            linear-gradient(207deg, #222 5px, transparent 5px) 10px 5px,
            linear-gradient(90deg, #1b1b1b 10px, transparent 10px),
            linear-gradient(#1d1d1d 25%, #1a1a1a 25%, #1a1a1a 50%, transparent 50%, transparent 75%, #242424 75%, #242424);
        background-color: #131313;
        background-size: 20px 20px;">

<div class="containme">

    <div id="btnDecon">
        <div style="margin-left: auto; margin-right: auto; text-align: center; padding-top: auto; padding-buttom: auto;">
            <form action="deconnexion.php" method="POST">
                <input class="btn btn-danger" type="submit" name="deconnexion" value="Déconnexion"
                    style="background-color: red;" />

            </form>

        </div>

    </div>
            <div style="margin-left: auto; margin-right: auto; text-align: center; padding-top: auto; padding-buttom: auto;">
            <div style="margin: auto; padding:auto;">
                                <br>
                
                <button type="button" class="btn btn-success launch" data-toggle="modal" data-target="#staticBackdrop">
                    <i class="fa fa-reach"></i>
                   SE CONNECTER ?
                </button>
            </div>
            
            <div class="modal fade" id="staticBackdrop" data-backdrop="static" data-keyboard="false" tabindex="-1"
                aria-labelledby="staticBackdropLabel" aria-hidden="true">

                <form action="antigenicValide.php" method="POST">

                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-body ">
                                <div class="d-flex justify-content-between align-items-center"
                                    style="text-align: center; border-bottom: 2px double #aaee13; font-weight: bold; font-size: 20px;">
                                    <span class="text-uppercase">Paramêtres de connexion: </span>
                                    <i class="fa fa-close close" data-dismiss="modal"></i>
                                </div>

                                <div class="row mt-12">
                                    <div class="col-md-12">
                                        <div class="d-flex flex-column">
                                            <span class="font-weight-bold">N° de téléphone</span>
                                            <!-- <input type="text" name="telephon_vacx" /> -->
                                            <h3 class="mb-0 font-weight-light">
                                                <input type="text" name="telephon_vacx" placeholder="Entrer n° de téléphone">
                                            </h3>
                                        </div>
                                    </div>
                                    
                                </div>

                                <div class="mt-3 d-flex flex-column" style="border-bottom: 2px double #aaee13; ">
                                    <span class="font-weight-bolder">
                                        <small>Cocher votre sexe ?</small></span>
                                </div>
                                <div class="mt-3" style="text-align: center;">
                                    <div class="row mt-1">
                                        <div class="col-md-6">
                                            <div class="form-check">
                                                <label class="form-check-label" for="flexRadioDefault1"> Masculin
                                                </label>
                                            </div>
                                            <div>

                                                <input class="form-check-input" type="radio" name="sexe_vacx"
                                                    id="flexRadioDefault1"  value ="1"/>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-check">
                                                <label class="form-check-label" for="flexRadioDefault2"> Féminin
                                                </label>
                                            </div>
                                            <div>
                                                <input class="form-check-input" type="radio" name="sexe_vacx"
                                                    id="flexRadioDefault2" value ="0">
                                                <!-- checked -->
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="mt-3 d-flex flex-column">
                                    <span class="font-weight-bolder">
                                        Entrer votre mot de passe?
                                    </span>
                                </div>

                                <div class="mt-3 text-center fee align-items-center">
                                    <h3 class="mb-0 font-weight-light">
                                        <input type="password" name="motpss" placeholder="Entrer le mot de passe">
                                    </h3>

                                </div>
                                

                                <hr class="mr-2 mt-4">
                                <div class="mt-3 mr-2 d-flex justify-content-end align-items-center">
                                    <a href="./testantigene.php" class="cancel">ANNULER </a>
                                    
                                    <button type="submit" role="button" class=" ml-2 btn btn-primary pay">
                                        CONNEXION
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>

                </form>
            </div>

        </div>

    
</div>
</body>

</html>