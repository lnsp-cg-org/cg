<html>

<head>

    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta content="IE=Edge" http-equiv="X-UA-Compatible" />
    <link rel="shortcut icon" href="https://lnsp-cg.org/images/republic-of-the-congo.svg" />

    <link href="https://lnsp-cg.org/pev/into/css/landing.css" media="screen" rel="stylesheet" type="text/css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>

    <link href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />

    <style>
    #top-bar {
        background: #4e2a84;
        text-align: left;
        color: #fff;
        font: 16px "akkuratpro-bold", sans-serif;
        text-transform: uppercase;
        padding: 1em;
        font-size: 16px;
    }

    .form-control {
        border-radius: 0;
        border-color: #123456;
        background-color: #123456;
        display: block;
        width: 100%;
        height: 34px;
        padding: 6px 12px;
        font-size: 17px;
        color: #fff;
        box-shadow: none;
        line-height: 1.42857143;
    }

    .select2-hidden-accessible {


        border: 0 !important;
        clip: rect(0 0 0 0) !important;
        height: 1px !important;
        margin: -1px !important;

        padding: 0 !important;
        position: absolute !important;
        width: 1px !important;
        background-color: #123456;

    }

    .form-control {
        -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
        box-shadow: inset 0 1px 1px rgba(0, 0, 0, .075);
        -webkit-transition: border-color ease-in-out .15s, -webkit-box-shadow ease-in-out .15s;
        -o-transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
        transition: border-color ease-in-out .15s, box-shadow ease-in-out .15s;
        background-color: #fff;
        background-image: none;
        border: 1px solid #ccc;
        border-radius: 4px;

    }

    .select2-container--default .select2-selection--single,
    .select2-selection .select2-selection--single {
        border: 1px solid #d2d6de;
        border-radius: 0;
        padding: 6px 12px;
        height: 34px;
        color: #fff;
        font-weight: bold;

        border-radius: 12px;

    }

    .select2-container--default .select2-selection--single {
        /**/
        color: #fff;
        border: 1px solid #aaa;

    }

    .select2-container .select2-selection--single {
        box-sizing: border-box;
        cursor: pointer;
        display: block;
        height: 28px;
        user-select: none;
        -webkit-user-select: none;

    }

    .select2-container .select2-selection--single .select2-selection__rendered {
        padding-right: 10px
    }

    .select2-container .select2-selection--single .select2-selection__rendered {
        padding-left: 0;
        padding-right: 0;
        height: auto;
        margin-top: -3px;

    }

    .select2-container--default .select2-selection--single .select2-selection__rendered {
        color: #444;
        line-height: 28px
    }

    .select2-container--default .select2-selection--single,
    .select2-selection .select2-selection--single {
        border: 1px solid #000000;
        border-radius: 10 !important;
        padding: 6px 12px;
        height: 40px !important;


    }

    .select2-container--default .select2-selection--single .select2-selection__arrow {
        height: 36px;
        top: 0px !important;
        right: 0px;

    }

    @media screen and (max-width: 650px) {
        .sidebar-brand-text {
            display: none;
        }
    }

    @media screen and (min-width: 650px) {
        #zname {
            display: none;
        }

        #LessTail {
            width: 30pt;
        }
    }

    /* 
    #container {
        
        width: 90%;
        margin: 0 auto;
        margin-top: 1px;
        text-align: center;
    } */

    input[type=submit]:hover {
        background-color: white;
        color: #53af57;
        border: 1px solid #d36b0a;
    }

    input[type=text]:hover {
        background-color: white;
        color: #53af57;
        border: 1px solid #d36b0a;
    }

    input[type=date]:hover {
        background-color: white;
        color: #53af57;
        border: 1px solid #d36b0a;
    }

    input[type=text] {
        background-color: white;
        color: #000;
        height: 50px;
        border: 1px solid #d36b0a;
    }

    input[type=date] {
        background-color: white;
        color: #000;
        height: 50px;
        border: 1px solid #d36b0a;
    }

    /*Bordered form */

    form {
        /*   "*/
        width: 100%;
        /**/
        padding-left: 22px;
        padding-right: 22px;
        border: 1px solid #f1f1f1;
        background: #fff;
        box-shadow: 0 0 20px 0 rgba(0, 0, 0, 0.2), 0 5px 5px 0 rgba(0, 0, 0, 0.24);
    }

    .col-12 {
        margin-top: 1%;

    }


    body {
        background: #333222;
    }

    #login {
        /* -webkit-perspective: 1000px;
          -moz-perspective: 1000px;
          perspective: 1000px;*/
        padding-top: 10px;
        margin-top: 3pt;
        margin-left: auto;
        margin-right: auto;
    }

    .login {
        font-family: 'Josefin Sans', sans-serif;
        -webkit-transition: .3s;
        -moz-transition: .3s;
        transition: .3s;

        margin-top: 3pt;
        /*
          -webkit-transform: rotateY(40deg);
          -moz-transform: rotateY(40deg);
          transform: rotateY(40deg);
          */
    }

    .login:hover {
        -webkit-transform: rotate(0);
        -moz-transform: rotate(0);
        transform: rotate(0);
    }



    .login .form-group {
        margin-bottom: 17px;
    }

    .login .form-control,
    .login .btn {
        border-radius: 0;
    }

    .login .btn {
        text-transform: uppercase;
        letter-spacing: 3px;
    }

    .input-group-addon {
        border-radius: 0;
        /*color:#fff;*/
        /*background:#f3aa0c;*/
        border: #f3aa0c;
    }

    .forgot {
        font-size: 13px;
    }

    .forgot a {
        color: #333;
    }

    .forgot a:hover {
        color: #5cb85c;
    }

    #inner-wrapper,
    #contact-us .contact-form,
    #contact-us .our-address {
        color: #1d1d1d;
        font-size: 19px;
        line-height: 1.7em;
        font-weight: 300;

        padding-left: 15px;
        padding-right: 15px;

        background: #fff;
        box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.16), 0 2px 10px 0 rgba(0, 0, 0, 0.12);
        margin-bottom: 100px;
    }

    .input-group-addon {
        border-radius: 0;
        border-top-right-radius: 0px;
        border-bottom-right-radius: 0px;
        color: #fff;

        background: #f3aa0c;
        border: #f3aa0c;
        border-right-color: rgb(243, 170, 12);
        border-right-style: none;
        border-right-width: medium;
    }

    .col-12 {
        margin-top: 1%;

    }

    .span4 {
        margin-right: 0px;
        float: right;

    }

    .span8 {
        text-align: left;


    }

    section article form div label {
        margin-top: 1%;
        text-align: left;
        font-weight: bold;
        color: #f3aa0c;

    }

    #leonce {
        margin-top: 1%;
        text-align: left;
        font-weight: bold;
        height: 50px;
        color: #000;

    }

    section article form div select {
        margin-top: 1%;
        text-align: left;
        font-weight: bold;
        height: 50px;
        color: #000;
        width: 39%;

    }

    blockquote {
        font-style: normal;
        font-size: 18px;
        margin-top: 3px;
        margin-left: 3px;
        margin-right: 3px;
        font-family: Consolas, "Times New Roman", Verdana;
        border-left: 4px solid #CCC;
        padding-left: 8px;
    }
    </style>

</head>

<body nselectstart="return false" oncontextmenu="return false" ondragstart="return false">

    <div class="col-md-6 " id="login">

        <div style="text-align: center;">
            <a role="button" class="btn btn-success" href="https://lnsp-cg.org/enregistre.php">
                <span style=" padding: auto; height: 4px;">
                    ACCUEIL
                </span>
            </a>
        </div>

        <div style="text-align: center; color: white;">
            <h3>FORMULAIRE DE PRE-ENREGISTREMENT DES DEMANDEURS DE TEST RT-PCR DE LA COVID-19</h3>

            <h4 class="mb-3">Veuillez remplir intégralement les champs ci-dessous, SVP!</h4>
            <hr />
            <b> <span>
                    <strong>* :informations obligatoire</strong>
                </span>
            </b>
        </div>



        <section id="inner-wrapper" class="login" style="margin-left: 1%; margin-right: 1%;">

            <br>
            <form class="" action="validerTestpcr.php" method="POST">


                <div
                    style="text-align: center; font-weight: 700; margin-left: auto; margin-right: auto; background-color: #aaaeee;">
                    <span>A. IDENTIFICATION</span>
                </div>

                <hr>


                <div class="col-12" style="color: black;">
                    <label for="ID_CARTE_IDENTITE" class="form-label">N° de passeport OU CNI (si non n° de
                        téléphone)</label>
                    <input type="text" class="form-control" name="ID_CARTE_IDENTITE" id="leonce ID_CARTE_IDENTITE"
                        placeholder="" value="" required="" placeholder="اN° de passeport OU CNI" />

                    <div class="invalid-feedback">
                        invalide champ
                    </div>
                </div>

                <div class="col-12" style="color: black;">
                    <label for="Q10" class="form-label">N° Téléphone</label>
                    <input type="text" class="form-control" name="Q10" id="leonce Q10" placeholder="" value=""
                        required="" placeholder="N° Téléphone " />

                    <div class="invalid-feedback">
                        invalide champ
                    </div>

                </div>

                <div class="col-12" style="color: black;">
                    <label for="Q06" class="form-label">Noms et prénoms</label>
                    <input type="text" class="form-control" name="Q06" id="leonce Q06" placeholder="" value=""
                        required="" />
                    <div class="invalid-feedback">
                        invalide champ
                    </div>

                </div>

                <div class="col-12" style="color: black;">
                    <label for="Q08" class="label">Sexe :</label>
                    <select id="leonce Q08" name="Q08" class="form-control" style=" color: black;" required="required">
                        <option selected=""></option>
                        <option value="MASCULIN">Masculin</option>
                        <option value="FEMININ ">Féminin</option>
                    </select>

                </div>

                <div class="col-12" style="color: black;">
                    <label for="Q09" class="form-label">Age</label>
                    <input type="text" class="form-control" name="Q09" id="leonce Q09" placeholder="" value=""
                        required="" pattern="\d{1,5}" maxlength="2" />


                    <div class="invalid-feedback">
                        invalide champ
                    </div>
                </div>

                <div class="col-12" style="color: black;">
                    <label for="Q09B" class="label">Professionl exercée :</label>
                    <input type="text" class="form-control" name="Q09B" id="leonce Q09B"
                        placeholder="Profession exercée" required="">
                    <div class="invalid-feedback">
                        invilade
                    </div>

                </div>

                <div class="col-12" style="color: black;">
                    <div class="span12">
                        <label for="STATUT_MATRIMONIAL" class="label">Statut matrimonial ? :</label>
                        <select id="leonce STATUT_MATRIMONIAL" name="STATUT_MATRIMONIAL" class="form-control"
                            style=" color: black;" required="required">
                            <option selected=""></option>
                            <option value="Enfant">Enfant</option>
                            <option value="Célibataire">Célibataire</option>
                            <option value="Union libre">Union libre</option>
                            <option value="Marié">Marié</option>
                            <option value="Veuf (ve)">Veuf (ve)</option>
                            <option value="Non indiqué">Non indiqué</option>
                        </select>
                    </div>
                </div>

                <div class="col-12" style="color: black;">
                    <div class="span12">
                        <label for="Q09A" class="label">Situation de la femme ? :</label>
                        <select id="leonce Q09A" name="Q09A" class="form-control" style=" color: black;"
                            required="required">
                            <option selected=""></option>
                            <option value="Non concere">Non conceré</option>
                            <option value="Enceinte">Enceinte</option>
                            <option value="Etat normal">Etat normal</option>
                        </select>
                    </div>
                </div>


                <div class="col-12" style="color: black;">
                    <label for="Q11D" class="form-label">Adresse de résidence au Congo</label>
                    <input type="text" class="form-control" name="Q11D" id="leonce Q11D"
                        placeholder="Adresse de résidence au Congo" required="">
                    <div class="invalid-feedback">
                        invilade
                    </div>
                </div>

                <div class="col-12" style="color: black;">
                    <label for="EMAIL_ADRS" class="form-label">Adresse émail</label>
                    <div class="input-group has-validation">
                        <span class="input-group-text">@</span>
                        <input type="email" class="form-control" name="EMAIL_ADRS" id="leonce EMAIL_ADRS"
                            placeholder="Email" required="">
                        <div class="invalid-feedback">
                            invalide
                        </div>
                    </div>
                </div>


                <div class="col-12" style="color: black;">
                    <!-- <label for="pays" class="form-label">
                        <span class="text-muted"></span>
                    </label> -->
                    <label for="PAYS" class="label">Pays de résidence habituel :</label>
                    <select id="leonce PAYS" name="PAYS" class="form-control" style=" color: black;">

                        <!-- <select name="PAYS" id="pays" class="select2"> -->
                        <!-- <select name="PAYS" id="pays" class="select2"> -->
<option value=""></option>
<optgroup label="C">
    <option value="REPUBLIQUE DU CONGO" data-indicatif="+242." data-taille="8-10">REPUBLIQUE DU CONGO</option>
    <option value="CONGO RDC" data-indicatif="+243." data-taille="8-10">CONGO - RDC</option>
    <option value="Chine" data-indicatif="+86." data-taille="8-12">République Populaire de Chine</option>
    <option value="CM" data-indicatif="+237." data-taille="8-10">Cameroun</option>
    <option value="KH" data-indicatif="+855." data-taille="8-10">Cambodge</option>
    <option value="CA" data-indicatif="+1." data-taille="8-10">Canada</option>
    <option value="CV" data-indicatif="+238." data-taille="8-10">Cap-Vert</option>
    <option value="CL" data-indicatif="+56." data-taille="8-10">Chili</option>
    <option value="CY" data-indicatif="+357." data-taille="8-10">Chypre</option>
    <option value="CO" data-indicatif="+57." data-taille="8-10">Colombie</option>
    <option value="KM" data-indicatif="+269." data-taille="8-10">Comores</option>
    <option value="KP" data-indicatif="+850." data-taille="8-10">Coree du Nord</option>
    <option value="KR" data-indicatif="+82." data-taille="8-10">Coree du Sud</option>
    <option value="CR" data-indicatif="+506." data-taille="8-10">Costa Rica</option>
    <option value="CI" data-indicatif="+225." data-taille="8-10">Côte d'Ivoire</option>
    <option value="HR" data-indicatif="+385." data-taille="8-10">Croatie</option>
    <option value="CU" data-indicatif="+53." data-taille="8-10">Cuba</option>
    <option value="CW" data-indicatif="+599." data-taille="10-13">CURACAO</option>
</optgroup>
<optgroup label="Europe">
    <option value="DE" data-indicatif="+49." data-taille="8-11">Allemagne</option>
    <option value="AT" data-indicatif="+43." data-taille="8-10">Autriche</option>
    <option value="BE" data-indicatif="+32." data-taille="8-9">Belgique</option>
    <option value="BG" data-indicatif="+359." data-taille="8-10">Bulgarie</option>
    <option value="CY" data-indicatif="+357." data-taille="8-10">Chypre</option>
    <option value="DK" data-indicatif="+45." data-taille="8-10">Danemark</option>
    <option value="ES" data-indicatif="+34." data-taille="8-12">Espagne</option>
    <option value="EE" data-indicatif="+372." data-taille="8-10">Estonie</option>
    <option value="FI" data-indicatif="+358." data-taille="8-10">Finlande</option>
    <option value="FR" data-indicatif="+33." data-taille="9-9">France</option>
    <option value="GI" data-indicatif="+350." data-taille="8-10">Gibraltar</option>
    <option value="GR" data-indicatif="+30." data-taille="8-10">Grèce</option>
    <option value="GP" data-indicatif="+590." data-taille="8-10">Guadeloupe</option>
    <option value="GF" data-indicatif="+594." data-taille="8-10">Guyane francaise</option>
    <option value="HU" data-indicatif="+36." data-taille="8-10">Hongrie</option>
    <option value="XI" data-indicatif="+34." data-taille="8-10">Iles canaries</option>
    <option value="IE" data-indicatif="+353." data-taille="8-10">Irlande</option>
    <option value="IS" data-indicatif="+354." data-taille="8-10">Islande</option>
    <option value="IT" data-indicatif="+39." data-taille="8-10">Italie</option>
    <option value="XK" data-indicatif="+381." data-taille="10-13">Kosovo</option>
    <option value="RE" data-indicatif="+262." data-taille="8-10">La Réunion</option>
    <option value="LV" data-indicatif="+371." data-taille="8-10">Lettonie</option>
    <option value="LI" data-indicatif="+423." data-taille="8-10">Liechtenstein</option>
    <option value="LT" data-indicatif="+370." data-taille="8-10">Lituanie</option>
    <option value="LU" data-indicatif="+352." data-taille="6-10">Luxembourg</option>
    <option value="MT" data-indicatif="+356." data-taille="8-10">Malte</option>
    <option value="MQ" data-indicatif="+596." data-taille="8-10">Martinique</option>
    <option value="YT" data-indicatif="+262." data-taille="8-10">Mayotte</option>
    <option value="NO" data-indicatif="+47." data-taille="8-10">Norvège</option>
    <option value="NL" data-indicatif="+31." data-taille="8-10">Pays-Bas</option>
    <option value="PL" data-indicatif="+48." data-taille="8-10">Pologne</option>
    <option value="PF" data-indicatif="+689." data-taille="8-10">Polynésie française</option>
    <option value="PT" data-indicatif="+351." data-taille="8-10">Portugal</option>
    <option value="CZ" data-indicatif="+420." data-taille="8-10">République tchèque</option>
    <option value="RO" data-indicatif="+40." data-taille="8-10">Roumanie</option>
    <option value="GB" data-indicatif="+44." data-taille="8-10">Royaume-Uni</option>
    <option value="PM" data-indicatif="+508." data-taille="8-10">Saint-Pierre-et-Miquelon</option>
    <option value="SK" data-indicatif="+421." data-taille="8-10">Slovaquie</option>
    <option value="SI" data-indicatif="+386." data-taille="8-10">Slovénie</option>
    <option value="SE" data-indicatif="+46." data-taille="8-10">Suède</option>
    <option value="WF" data-indicatif="+681." data-taille="8-10">Wallis-et-Futuna</option>
</optgroup>
<optgroup label="A">
    <option value="AF" data-indicatif="+93." data-taille="8-10">Afghanistan</option>
    <option value="ZA" data-indicatif="+27." data-taille="8-10">Afrique du Sud</option>
    <option value="AL" data-indicatif="+355." data-taille="8-10">Albanie</option>
    <option value="DZ" data-indicatif="+213." data-taille="8-10">Algérie</option>
    <option value="DE" data-indicatif="+49." data-taille="8-11">Allemagne</option>
    <option value="AD" data-indicatif="+376." data-taille="8-10">Andorre</option>
    <option value="AO" data-indicatif="+244." data-taille="8-10">Angola</option>
    <option value="AI" data-indicatif="+1264." data-taille="8-10">Anguilla</option>
    <option value="AG" data-indicatif="+1268." data-taille="8-10">Antigua-et-Barbuda</option>
    <option value="AN" data-indicatif="+599." data-taille="8-10">Antilles néerlandaises</option>
    <option value="SA" data-indicatif="+966." data-taille="8-10">Arabie saoudite</option>
    <option value="AR" data-indicatif="+54." data-taille="8-10">Argentine</option>
    <option value="AM" data-indicatif="+374." data-taille="8-10">Arménie</option>
    <option value="AW" data-indicatif="+297." data-taille="8-10">Aruba</option>
    <option value="AU" data-indicatif="+61." data-taille="8-10">Australie</option>
    <option value="AT" data-indicatif="+43." data-taille="8-10">Autriche</option>
    <option value="AZ" data-indicatif="+994." data-taille="8-10">Azerbaïdjan</option>
</optgroup>
<optgroup label="B">
    <option value="BS" data-indicatif="+1242." data-taille="8-10">Bahamas</option>
    <option value="BH" data-indicatif="+973." data-taille="8-10">Bahreïn</option>
    <option value="BD" data-indicatif="+880." data-taille="8-10">Bangladesh</option>
    <option value="BB" data-indicatif="+1246." data-taille="8-10">Barbade</option>
    <option value="BE" data-indicatif="+32." data-taille="8-9">Belgique</option>
    <option value="BZ" data-indicatif="+501." data-taille="8-10">Belize</option>
    <option value="BJ" data-indicatif="+229." data-taille="8-10">Bénin</option>
    <option value="BM" data-indicatif="+1441." data-taille="8-10">Bermudes</option>
    <option value="BT" data-indicatif="+975." data-taille="8-10">Bhoutan</option>
    <option value="BO" data-indicatif="+591." data-taille="8-10">Bolivie</option>
    <option value="BA" data-indicatif="+387." data-taille="8-10">Bosnie-Herzégovine</option>
    <option value="BW" data-indicatif="+267." data-taille="8-10">Botswana</option>
    <option value="BR" data-indicatif="+55." data-taille="8-11">Brésil</option>
    <option value="BN" data-indicatif="+673." data-taille="8-10">Brunei</option>
    <option value="BG" data-indicatif="+359." data-taille="8-10">Bulgarie</option>
    <option value="BF" data-indicatif="+226." data-taille="8-10">Burkina Faso</option>
    <option value="BI" data-indicatif="+257." data-taille="8-10">Burundi</option>
</optgroup>
<optgroup label="D">
    <option value="DK" data-indicatif="+45." data-taille="8-10">Danemark</option>
    <option value="DJ" data-indicatif="+253." data-taille="8-10">Djibouti</option>
    <option value="DM" data-indicatif="+1767." data-taille="8-10">Dominique</option>
</optgroup>
<optgroup label="E">
    <option value="EG" data-indicatif="+20." data-taille="8-10">Egypte</option>
    <option value="AE" data-indicatif="+971." data-taille="8-10">Emirats-arabes-unis</option>
    <option value="ES" data-indicatif="+34." data-taille="8-12">Espagne</option>
    <option value="EE" data-indicatif="+372." data-taille="8-10">Estonie</option>
    <option value="US" data-indicatif="+1." data-taille="8-10">Etats-Unis</option>
    <option value="ET" data-indicatif="+251." data-taille="8-10">Ethiopie</option>
</optgroup>
<optgroup label="F">
    <option value="FJ" data-indicatif="+679." data-taille="8-10">Fidji</option>
    <option value="FI" data-indicatif="+358." data-taille="8-10">Finlande</option>
    <option value="FR" data-indicatif="+33." data-taille="9-9">France</option>
</optgroup>
<optgroup label="G">
    <option value="GA" data-indicatif="+241." data-taille="8-10">Gabon</option>
    <option value="GM" data-indicatif="+220." data-taille="8-10">Gambie</option>
    <option value="GE" data-indicatif="+995." data-taille="8-10">Géorgie</option>
    <option value="GH" data-indicatif="+233." data-taille="8-10">Ghana</option>
    <option value="GI" data-indicatif="+350." data-taille="8-10">Gibraltar</option>
    <option value="GR" data-indicatif="+30." data-taille="8-10">Grèce</option>
    <option value="GD" data-indicatif="+1473." data-taille="8-10">Grenade</option>
    <option value="GL" data-indicatif="+299." data-taille="8-10">Groenland</option>
    <option value="GP" data-indicatif="+590." data-taille="8-10">Guadeloupe</option>
    <option value="GU" data-indicatif="+1671." data-taille="8-10">Guam</option>
    <option value="GT" data-indicatif="+502." data-taille="8-10">Guatemala</option>
    <option value="GN" data-indicatif="+224." data-taille="8-10">Guinée</option>
    <option value="GQ" data-indicatif="+240." data-taille="8-10">Guinée équatoriale</option>
    <option value="GW" data-indicatif="+245." data-taille="8-10">Guinée-Bissau</option>
    <option value="GY" data-indicatif="+592." data-taille="8-10">Guyana</option>
    <option value="GF" data-indicatif="+594." data-taille="8-10">Guyane francaise</option>
</optgroup>
<optgroup label="H">
    <option value="HT" data-indicatif="+509." data-taille="8-10">Haïti</option>
    <option value="HN" data-indicatif="+504." data-taille="8-10">Honduras</option>
    <option value="HK" data-indicatif="+852." data-taille="8-10">Hong Kong</option>
    <option value="HU" data-indicatif="+36." data-taille="8-10">Hongrie</option>
</optgroup>
<optgroup label="I">
    <option value="MF" data-indicatif="+534." data-taille="8-10">Ile de saint martin (francaise)</option>
    <option value="SX" data-indicatif="+534." data-taille="8-10">Ile de saint martin (néerlandaise)</option>
    <option value="XI" data-indicatif="+34." data-taille="8-10">Iles canaries</option>
    <option value="IN" data-indicatif="+91." data-taille="8-10">Inde</option>
    <option value="ID" data-indicatif="+62." data-taille="8-12">Indonésie</option>
    <option value="IQ" data-indicatif="+964." data-taille="8-10">Irak</option>
    <option value="IR" data-indicatif="+98." data-taille="8-10">Iran</option>
    <option value="IE" data-indicatif="+353." data-taille="8-10">Irlande</option>
    <option value="IS" data-indicatif="+354." data-taille="8-10">Islande</option>
    <option value="IL" data-indicatif="+972." data-taille="8-10">Israel</option>
    <option value="IT" data-indicatif="+39." data-taille="8-10">Italie</option>
</optgroup>
<optgroup label="J">
    <option value="JM" data-indicatif="+1876." data-taille="8-10">Jamaïque</option>
    <option value="JP" data-indicatif="+81." data-taille="8-10">Japon</option>
    <option value="JO" data-indicatif="+962." data-taille="8-10">Jordanie</option>
</optgroup>
<optgroup label="K">
    <option value="KZ" data-indicatif="+7." data-taille="8-10">Kazakhstan</option>
    <option value="KE" data-indicatif="+254." data-taille="8-10">Kenya</option>
    <option value="KG" data-indicatif="+996." data-taille="8-10">Kirghizistan</option>
    <option value="KI" data-indicatif="+686." data-taille="8-10">Kiribati</option>
    <option value="XK" data-indicatif="+381." data-taille="10-13">Kosovo</option>
    <option value="KW" data-indicatif="+965." data-taille="8-10">Koweït</option>
</optgroup>
<optgroup label="L">
    <option value="RE" data-indicatif="+262." data-taille="8-10">La Réunion</option>
    <option value="LA" data-indicatif="+856." data-taille="8-10">Laos</option>
    <option value="LS" data-indicatif="+266." data-taille="8-10">Lesotho</option>
    <option value="LV" data-indicatif="+371." data-taille="8-10">Lettonie</option>
    <option value="LB" data-indicatif="+961." data-taille="8-10">Liban</option>
    <option value="LR" data-indicatif="+231." data-taille="8-10">Liberia</option>
    <option value="LY" data-indicatif="+218." data-taille="8-10">Libye</option>
    <option value="LI" data-indicatif="+423." data-taille="8-10">Liechtenstein</option>
    <option value="LT" data-indicatif="+370." data-taille="8-10">Lituanie</option>
    <option value="LU" data-indicatif="+352." data-taille="6-10">Luxembourg</option>
</optgroup>
<optgroup label="M">
    <option value="MO" data-indicatif="+853." data-taille="8-10">Macao</option>
    <option value="MK" data-indicatif="+389." data-taille="8-10">Macédoine</option>
    <option value="MG" data-indicatif="+261." data-taille="8-10">Madagascar</option>
    <option value="MY" data-indicatif="+60." data-taille="8-10">Malaisie</option>
    <option value="MW" data-indicatif="+265." data-taille="8-10">Malawi</option>
    <option value="MV" data-indicatif="+960." data-taille="8-10">Maldives</option>
    <option value="ML" data-indicatif="+223." data-taille="8-10">Mali</option>
    <option value="MT" data-indicatif="+356." data-taille="8-10">Malte</option>
    <option value="MA" data-indicatif="+212." data-taille="8-10">Maroc</option>
    <option value="MH" data-indicatif="+692." data-taille="8-10">Marshall</option>
    <option value="MQ" data-indicatif="+596." data-taille="8-10">Martinique</option>
    <option value="MU" data-indicatif="+230." data-taille="8-10">Maurice</option>
    <option value="MR" data-indicatif="+222." data-taille="8-10">Mauritanie</option>
    <option value="YT" data-indicatif="+262." data-taille="8-10">Mayotte</option>
    <option value="MX" data-indicatif="+52." data-taille="8-10">Mexique</option>
    <option value="FM" data-indicatif="+691." data-taille="8-10">Micronésie</option>
    <option value="MD" data-indicatif="+373." data-taille="8-10">Moldavie</option>
    <option value="MC" data-indicatif="+377." data-taille="8-10">Monaco</option>
    <option value="MN" data-indicatif="+976." data-taille="8-10">Mongolie</option>
    <option value="ME" data-indicatif="+382." data-taille="8-10">Monténégro</option>
    <option value="MS" data-indicatif="+1664." data-taille="8-10">Montserrat</option>
    <option value="MZ" data-indicatif="+258." data-taille="8-10">Mozambique</option>
</optgroup>
<optgroup label="N">
    <option value="NA" data-indicatif="+264." data-taille="8-10">Namibie</option>
    <option value="NR" data-indicatif="+674." data-taille="8-10">Nauru</option>
    <option value="NP" data-indicatif="+977." data-taille="8-10">Népal</option>
    <option value="NI" data-indicatif="+505." data-taille="8-10">Nicaragua</option>
    <option value="NE" data-indicatif="+227." data-taille="8-10">Niger</option>
    <option value="NG" data-indicatif="+234." data-taille="8-10">Nigeria</option>
    <option value="NU" data-indicatif="+683." data-taille="8-10">Niue</option>
    <option value="NO" data-indicatif="+47." data-taille="8-10">Norvège</option>
    <option value="NC" data-indicatif="+687." data-taille="6-8">Nouvelle-Calédonie</option>
    <option value="NZ" data-indicatif="+64." data-taille="8-10">Nouvelle-Zélande</option>
</optgroup>
<optgroup label="O">
    <option value="OM" data-indicatif="+968." data-taille="8-10">Oman</option>
    <option value="UG" data-indicatif="+256." data-taille="8-10">Ouganda</option>
    <option value="UZ" data-indicatif="+998." data-taille="8-10">Ouzbékistan</option>
</optgroup>
<optgroup label="P">
    <option value="PK" data-indicatif="+92." data-taille="8-10">Pakistan</option>
    <option value="PW" data-indicatif="+680." data-taille="8-10">Palaos</option>
    <option value="PA" data-indicatif="+507." data-taille="8-10">Panamá</option>
    <option value="PG" data-indicatif="+675." data-taille="8-10">Papouasie-Nouvelle-Guinée</option>
    <option value="PY" data-indicatif="+595." data-taille="8-10">Paraguay</option>
    <option value="NL" data-indicatif="+31." data-taille="8-10">Pays-Bas</option>
    <option value="PE" data-indicatif="+51." data-taille="8-10">Pérou</option>
    <option value="PH" data-indicatif="+63." data-taille="8-10">Philippines</option>
    <option value="PL" data-indicatif="+48." data-taille="8-10">Pologne</option>
    <option value="PF" data-indicatif="+689." data-taille="8-10">Polynésie française</option>
    <option value="PR" data-indicatif="+1." data-taille="8-10">Porto Rico</option>
    <option value="PT" data-indicatif="+351." data-taille="8-10">Portugal</option>
</optgroup>
<optgroup label="Q">
    <option value="QA" data-indicatif="+974." data-taille="8-10">Qatar</option>
</optgroup>
<optgroup label="R">
    <option value="CF" data-indicatif="+236." data-taille="8-10">Republique centrafricaine</option>
    <option value="DO" data-indicatif="+1." data-taille="8-10">République dominicaine</option>
    <option value="CZ" data-indicatif="+420." data-taille="8-10">République tchèque</option>
    <option value="RO" data-indicatif="+40." data-taille="8-10">Roumanie</option>
    <option value="GB" data-indicatif="+44." data-taille="8-10">Royaume-Uni</option>
    <option value="RU" data-indicatif="+7." data-taille="8-10">Russie</option>
    <option value="RW" data-indicatif="+250." data-taille="8-10">Rwanda</option>
</optgroup>
<optgroup label="S">
    <option value="BL" data-indicatif="+652." data-taille="8-10">Saint barthelemy</option>
    <option value="SM" data-indicatif="+663." data-taille="8-10">Saint marin</option>
    <option value="SM" data-indicatif="+378." data-taille="8-10">Saint-Marin</option>
    <option value="PM" data-indicatif="+508." data-taille="8-10">Saint-Pierre-et-Miquelon</option>
    <option value="VC" data-indicatif="+1784." data-taille="8-10">Saint-Vincent-et-les Grenadines</option>
    <option value="SH" data-indicatif="+290." data-taille="8-10">Sainte-Hélène, île</option>
    <option value="LC" data-indicatif="+1758." data-taille="8-10">Sainte-Lucie</option>
    <option value="SB" data-indicatif="+677." data-taille="8-10">Salomon</option>
    <option value="WS" data-indicatif="+685." data-taille="8-10">Samoa</option>
    <option value="AS" data-indicatif="+1684." data-taille="8-10">Samoa américaines</option>
    <option value="ST" data-indicatif="+239." data-taille="8-10">Sao Tomé-et-Principe</option>
    <option value="SN" data-indicatif="+221." data-taille="8-10">Sénégal</option>
    <option value="RS" data-indicatif="+381." data-taille="8-10">Serbie</option>
    <option value="SC" data-indicatif="+248." data-taille="8-10">Seychelles</option>
    <option value="SL" data-indicatif="+232." data-taille="8-10">Sierra Leone</option>
    <option value="SG" data-indicatif="+65." data-taille="8-10">Singapour</option>
    <option value="SK" data-indicatif="+421." data-taille="8-10">Slovaquie</option>
    <option value="SI" data-indicatif="+386." data-taille="8-10">Slovénie</option>
    <option value="SO" data-indicatif="+252." data-taille="8-10">Somalie</option>
    <option value="SD" data-indicatif="+249." data-taille="8-10">Soudan</option>
    <option value="LK" data-indicatif="+94." data-taille="8-10">Sri Lanka</option>
    <option value="SE" data-indicatif="+46." data-taille="8-10">Suède</option>
    <option value="CH" data-indicatif="+41." data-taille="8-10">Suisse</option>
    <option value="SR" data-indicatif="+597." data-taille="8-10">Suriname</option>
    <option value="SZ" data-indicatif="+268." data-taille="8-10">Swaziland</option>
</optgroup>
<optgroup label="T">
    <option value="TJ" data-indicatif="+992." data-taille="8-10">Tadjikistan</option>
    <option value="TW" data-indicatif="+886." data-taille="8-10">Taïwan (République de Chine)</option>
    <option value="TZ" data-indicatif="+255." data-taille="8-10">Tanzanie</option>
    <option value="TD" data-indicatif="+235." data-taille="8-10">Tchad</option>
    <option value="TH" data-indicatif="+66." data-taille="8-10">Thaïlande</option>
    <option value="TG" data-indicatif="+228." data-taille="8-10">Togo</option>
    <option value="TK" data-indicatif="+690." data-taille="8-10">Tokelau</option>
    <option value="TO" data-indicatif="+676." data-taille="8-10">Tonga</option>
    <option value="TT" data-indicatif="+1868." data-taille="8-10">Trinité-et-Tobago</option>
    <option value="TN" data-indicatif="+216." data-taille="8-10">Tunisie</option>
    <option value="TM" data-indicatif="+993." data-taille="8-10">Turkménistan</option>
    <option value="TR" data-indicatif="+90." data-taille="8-10">Turquie</option>
    <option value="TV" data-indicatif="+688." data-taille="8-10">Tuvalu</option>
</optgroup>
<optgroup label="U">
    <option value="UA" data-indicatif="+380." data-taille="8-10">Ukraine</option>
    <option value="UY" data-indicatif="+598." data-taille="8-10">Uruguay</option>
</optgroup>
<optgroup label="V">
    <option value="VU" data-indicatif="+678." data-taille="8-10">Vanuatu</option>
    <option value="VE" data-indicatif="+58." data-taille="8-10">Venezuela</option>
    <option value="VN" data-indicatif="+84." data-taille="8-10">Viêt Nam</option>
</optgroup>
<optgroup label="W">
    <option value="WF" data-indicatif="+681." data-taille="8-10">Wallis-et-Futuna</option>
</optgroup>
<optgroup label="X"></optgroup>
<optgroup label="Y">
    <option value="YE" data-indicatif="+967." data-taille="8-10">Yémen</option>
</optgroup>
<!-- </select> -->                    </select>
                </div>

                <br>
                <div
                    style="text-align: center; font-weight: 700; margin-left: auto; margin-right: auto; background-color: #aaaeee;">
                    <span>B. VACCINATION CONTRE LA COVID</span>
                </div>

                <hr>
                <div class="col-12" style="color: black;">
                    <div class="span12">
                        <span class="span8">Avoir déjà pris le vaccin contre la covid</span>
                        <span class="span4">
                            <input type="radio" name="VACCINATION_COVID" id="VACCINATION_COVID" value="0">
                            <label class="radio inline" for="VACCINATION_COVID">Non</label>

                            <input type="radio" name="VACCINATION_COVID" id="VACCINATION_COVID2" value="1" checked="">
                            <label class="radio inline" for="VACCINATION_COVID2">Oui</label>
                        </span>
                    </div>
                </div>


                <div class="col-12" style="color: black;">
                    <label for="TYPE_DE_VACCIN_RECU" class="label">Quel vaccin avez-vous pris :</label>
                    <select id="leonce TYPE_DE_VACCIN_RECU" name="TYPE_DE_VACCIN_RECU" class="form-control"
                        style=" color: black;">
                        <option selected=""></option>
                        <option value="SINOPHARM">Sinopharm</option>
                        <option value="SPUTNIK-V ">Sputnik-V</option>
                        <option value="ASTRAZENECA">Astrazeneca</option>
                        <option value="JANSSEN">Janseen</option>
                        <option value="MODERNA">Moderna</option>
                        <option value="PFIZER">PFizer</option>
                        <option value="SPUTNIK-LITE">Sputnik-Light</option>
                    </select>

                </div>


                <div class="col-12">
                    <label for="DATE_DE_LA_1ERE_DOSE" class="form-label">Date de la dernière dose du vaccin:</label>
                    <input type="Date" class="form-control" name="DATE_DE_LA_1ERE_DOSE" id="leonce DATE_DE_LA_1ERE_DOSE"
                        placeholder="" value="">
                    <div class="invalid-feedback">
                        invalide champ
                    </div>
                </div>


                <div class="col-12" style="color: black;">
                    <div class="span12">
                        <span class="span8">Avez-vous manipulé des animaux les jours précédents ?</span>

                        <span class="span4">
                            <input type="radio" name="Q60" id="Q60" value="0">
                            <label class="radio inline" for="Q60">Non</label>

                            <input type="radio" name="Q60" id="Q602" value="1" checked="">
                            <label class="radio inline" for="Q602">Oui</label>
                        </span>
                    </div>
                </div>

                <div class="col-12" style="color: black;">
                    <div class="span12">
                        <label for="Q61">Types d’animaux manipulés (p. ex. porcs, poulets, canards ou autres)</label>
                        <input type="text" class="form-control" name="Q61" id="leonce Q61" placeholder="" value="">
                        <div class="invalid-feedback">
                            invalide champ
                        </div>
                    </div>
                </div>



                <hr>
                <div
                    style="text-align: center; font-weight: 700; margin-left: auto; margin-right: auto; background-color: #aaaeee;">
                    <span>C. SYMPTOMES DE LA COVID</span>
                </div>
                <span style="text-align: center;">
                    Avez-vous senti au moins l’un des symptômes de la Covid19 ?
                </span>

                <hr>


                <div class="col-12" style="color: black;">
                    <label for="ETAT_SP" class="label">Avez - vous eu des symptomes de la covid? :</label>
                    <select id="leonce ETAT_SP" name="ETAT_SP" class="form-control" style=" color: black;"
                        required="required">
                        <option selected=""></option>
                        <option value="Asymptomatique">Non, asymptomatique</option>
                        <option value="Symptomatique">Oui, symptomatique</option>
                    </select>

                </div>

                <br>
                <hr>
                <blockquote>
                    <span class="span12">Évolution clinique du patient</span>

                    <div class="col-12" style="color: black;">
                        <div class="span12">
                            <span class="span8">
                                Avez-vous eu des écoulements nasaux?
                            </span>

                            <span class="span4">
                                <input type="radio" name="Q18" id="Q18" value="0">
                                <label class="radio inline" for="Q18">Non</label>

                                <input type="radio" name="Q18" id="Q182" value="1" checked="">
                                <label class="radio inline" for="Q182">Oui</label>
                            </span>
                        </div>
                    </div>

                    <div class="col-12" style="color: black;">
                        <div class="span12">
                            <span class="span8">
                                Avez-vous eu de la taux sec ?
                            </span>

                            <span class="span4">
                                <input type="radio" name="Q19" id="Q19" value="0">
                                <label class="radio inline" for="Q19">Non</label>

                                <input type="radio" name="Q18" id="Q192" value="1" checked="">
                                <label class="radio inline" for="Q192">Oui</label>
                            </span>
                        </div>
                    </div>


                    <div class="col-12" style="color: black;">
                        <div class="span12">
                            <span class="span8">Mal de gorge ?</span>

                            <span class="span4">
                                <input type="radio" name="Q20" id="Q20" value="0">
                                <label class="radio inline" for="Q20">Non</label>

                                <input type="radio" name="Q20" id="Q202" value="1" checked="">
                                <label class="radio inline" for="Q202">Oui</label>
                            </span>
                        </div>
                    </div>

                    <div class="col-12" style="color: black;">
                        <div class="span12">
                            <span class="span8">Souffère de l'asthénie ?</span>

                            <span class="span4">
                                <input type="radio" name="Q21" id="Q21" value="0">
                                <label class="radio inline" for="Q21">Non</label>

                                <input type="radio" name="Q21" id="Q212" value="1" checked="">
                                <label class="radio inline" for="Q212">Oui</label>
                            </span>
                        </div>
                    </div>

                    <div class="col-12" style="color: black;">
                        <div class="span12">
                            <span class="span8">Difficultés respiratoire ?</span>

                            <span class="span4">
                                <input type="radio" name="Q22" id="Q22" value="0">
                                <label class="radio inline" for="Q22">Non</label>

                                <input type="radio" name="Q22" id="Q222" value="1" checked="">
                                <label class="radio inline" for="Q222">Oui</label>
                            </span>
                        </div>
                    </div>


                    <div class="col-12" style="color: black;">
                        <div class="span12">
                            <span class="span8">Avoir senti des éssoufflements?</span>

                            <span class="span4">
                                <input type="radio" name="Q23" id="Q23" value="0">
                                <label class="radio inline" for="Q23">Non</label>

                                <input type="radio" name="Q23" id="Q232" value="1" checked="">
                                <label class="radio inline" for="Q232">Oui</label>
                            </span>
                        </div>
                    </div>


                    <div class="col-12" style="color: black;">
                        <div class="span12">
                            <span class="span8">Douleurs musculaires ?</span>

                            <span class="span4">
                                <input type="radio" name="Q24" id="Q24" value="0">
                                <label class="radio inline" for="Q24">Non</label>

                                <input type="radio" name="Q24" id="DOULEURS_MUSCULAIRES2" value="1" checked="">
                                <label class="radio inline" for="Q242">Oui</label>
                            </span>
                        </div>
                    </div>


                    <div class="col-12" style="color: black;">
                        <div class="span12">
                            <span class="span8">Signes neurologiques</span>

                            <span class="span4">
                                <input type="radio" name="Q25" id="Q25" value="0">
                                <label class="radio inline" for="Q25">Non</label>

                                <input type="radio" name="Q25" id="Q252" value="1" checked="">
                                <label class="radio inline" for="Q252">Oui</label>
                            </span>
                        </div>
                    </div>

                    <div class="col-12" style="color: black;">
                        <div class="span12">
                            <span class="span8">Avoir de la fièvre de plus de 38°C :</span>

                            <span class="span4">
                                <input type="radio" name="Q26" id="Q26" value="0">
                                <label class="radio inline" for="Q26">Non</label>

                                <input type="radio" name="Q26" id="Q262" value="1" checked="">
                                <label class="radio inline" for="Q262">Oui</label>
                            </span>
                        </div>
                    </div>

                </blockquote>



                <hr>

                <div
                    style="text-align: center; font-weight: 700; margin-left: auto; margin-right: auto; background-color: #aaaeee; ">
                    <span>ANTECEDENTS MEDICAUX</span>
                </div>

                <hr>
                <blockquote>

                    <div class="col-12" style="color: black;">
                        <div class="span12">
                            <span class="span8">Avoir un cancer ?</span>

                            <span class="span4">
                                <input type="radio" name="Q28" id="Q28" value="0">
                                <label class="radio inline" for="Q28">Non</label>

                                <input type="radio" name="Q28" id="Q282" value="1" checked="">
                                <label class="radio inline" for="Q282">Oui</label>
                            </span>
                        </div>
                    </div>

                    <div class="col-12" style="color: black;">
                        <div class="span12">
                            <span class="span8">Souffrir du diabète</span>

                            <span class="span4">
                                <input type="radio" name="Q29" id="Q29" value="0">
                                <label class="radio inline" for="Q29">Non</label>

                                <input type="radio" name="Q29" id="Q292" value="1" checked="">
                                <label class="radio inline" for="Q292">Oui</label>
                            </span>
                        </div>
                    </div>

                    <div class="col-12" style="color: black;">
                        <div class="span12">
                            <span class="span8">Souffrir de l'Asthme</span>

                            <span class="span4">
                                <input type="radio" name="Q32" id="Q32" value="0">
                                <label class="radio inline" for="Q32">Non</label>

                                <input type="radio" name="Q32" id="Q322" value="1" checked="">
                                <label class="radio inline" for="Q322">Oui</label>
                            </span>
                        </div>
                    </div>

                    <div class="col-12" style="color: black;">
                        <div class="span12">
                            <span class="span8">Souffrir de la drépanocytose</span>

                            <span class="span4">
                                <input type="radio" name="Q34" id="Q34" value="0">
                                <label class="radio inline" for="Q34">Non</label>

                                <input type="radio" name="Q34" id="Q342" value="1" checked="">
                                <label class="radio inline" for="Q342">Oui</label>
                            </span>
                        </div>
                    </div>

                    <div class="col-12" style="color: black;">
                        <div class="span12">
                            <span class="span8">HTA (l'hypertension artérielle : HTA)</span>

                            <span class="span4">
                                <input type="radio" name="Q35" id="Q35" value="0">
                                <label class="radio inline" for="Q35">Non</label>

                                <input type="radio" name="Q35" id="Q352" value="1" checked="">
                                <label class="radio inline" for="Q352">Oui</label>
                            </span>
                        </div>
                    </div>


                    <div class="col-12" style="color: black;">
                        <div class="span12">
                            <span class="span8">
                                Avoir une maladie pulmonaire chronique
                            </span>

                            <span class="span4">
                                <input type="radio" name="Q33" id="Q33" value="0">
                                <label class="radio inline" for="Q33">Non</label>

                                <input type="radio" name="Q33" id="Q332" value="1" checked="">
                                <label class="radio inline" for="Q332">Oui</label>
                            </span>
                        </div>
                    </div>


                    <div class="col-12" style="color: black;">
                        <div class="span12">
                            <span class="span8">Avoir une maladie cardiaque ?</span>

                            <span class="span4">
                                <input type="radio" name="Q31" id="Q31" value="0">
                                <label class="radio inline" for="Q31">Non</label>

                                <input type="radio" name="Q31" id="Q312" value="1" checked="">
                                <label class="radio inline" for="Q312">Oui</label>
                            </span>
                        </div>
                    </div>

                    <div class="col-12" style="color: black;">
                        <div class="span12">
                            <span class="span8">Si femme, êtes-vous enceinte?</span>

                            <span class="span4">
                                <input type="radio" name="Q36" id="Q36" value="0">
                                <label class="radio inline" for="Q36">Non</label>

                                <input type="radio" name="Q36" id="Q362" value="1" checked="">
                                <label class="radio inline" for="Q362">Oui</label>
                            </span>
                        </div>
                    </div>

                </blockquote>


                <hr class="my-4">

                <div style="margin: auto; padding: auto;">
                    <button type="submit" class="btn btn-success btn-block">Envoyer</button>

                    <a href="enregistre.php" class="btn btn-warning">Annuler</a>

                </div>


            </form>

        </section>
    </div>




    <script>
    // Fonction executée lors de l'utilisation du clic droit.
    $(document).bind("contextmenu", function() {
        alert('Merci de respecter le contenu en ne pas le copier sans autorisation!');
        return false;
    });
    </script>
</body>




    <footer class=" py-2 bg-dark"> <!--- fixed-bottom -->
      <div style="height:2pt; background: #ffde00;"> </div>
      <div>
          <p class="m-0 text-center text-white fixed-down">
            Copyright &copy; Laboratoire National de Santé Publique 2021
          </p>
      </div>

    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script>
      // Fonction executée lors de l'utilisation du clic droit.
      $(document).bind("contextmenu",function()
      {
      alert('Merci de respecter le contenu en ne pas le copier sans autorisation!');
      return false;
      });
    </script>

</body></hmtl>