

<!DOCTYPE html>
<html lang="fr">

<head>
    <title>LNSP-CG</title>
        <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script> -->


    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>

    <link href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />



    <link rel="shortcut icon" href="images/republic-of-the-congo.svg" />

    <link rel="stylesheet" href="cssmenu.css">

    <style>
    .blink_me {
        background: rgba(11, 42, 155, 0.124);
        animation: blinker 2s linear infinite;
    }

    @keyframes blinker {
        65% {
            opacity: 0.52;
        }
    }

    @media screen and (max-width: 600px) {

        .sidebar-brand-text,
        #xname {
            display: none;
        }

        #xmenu {
            float: right;
        }
    }

    @media screen and (min-width: 600px) {
        .navbar-brand {
            font-size: 10px;
        }

        #zname {
            display: none;
        }

    }
    </style>
    <script type="text/javascript">
    window.$crisp = [];
    window.CRISP_WEBSITE_ID = "286073c0-a54f-4930-92cc-20a0de5c53b5";
    (function() {
        d = document;
        s = d.createElement("script");
        s.src = "https://client.crisp.chat/l.js";
        s.async = 1;
        d.getElementsByTagName("head")[0].appendChild(s);
    })();
    </script>
</head>

<body>
    <header>
        <nav class="navbar navbar-light bg-light">
            <div class="navbar navbar-inverse navbar-fixed-top bs-docs-nav" role="banner">
                <a class="navbar-brand" href="#">
                    <h3 class="text-center text-white bg-dark font-weight-bold fixed-top">
                        <img src="images/republic-of-the-congo.svg" width="60" height="45" alt="Drapeau Congolais" />
                        <spam>
                            <a id="xname" href="#" style="color: #ffffff;">LABORATOIRE NATIONAL DE SANTE PUBLIQUE</a>
                            <a id="zname" href="#" style="color: #ffffff;">LNSP - CONGO</a>
                        </spam>

                    </h3>
                </a>
            </div>
        </nav>

        <div style="height:12pt; background: #e70000;">

        </div>
        <nav style="background: #e700F0;"
            class="navbar navbar-expand-lg shadow-lg navbar-dark h7 text-center bg-dark fixed-relative navbar-fixed-top">
            <div id="xmenu" class="" style=" margin:auto;" role="banner">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive"
                    aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-center navbar-inverse bs-docs-nav"
                    id="navbarResponsive" style="margin:0pt; padding:8pt;">

                    <ul class="nav-item navbar-nav ">

                        <!-- style="margin:2pt; padding:6pt;" -->
                        <li class="active">
                            <a class="nav-link" role="button" href="https://lnsp-cg.org/ncov2" class="btn btn-outline-warning">
                                VOTRE RESULTAT ICI
                                <!--<button type="button" class="btn btn-outline-warning"></button -->
                            </a>
                        </li>
                        <!-- style="margin:2pt; padding:6pt;" -->
                        <li class="active">
                            <a class="nav-link" href="https://lnsp-cg.org/testantigene.php" >
                                TESTS-ANTIGENIQUES
                                <!--<button type="button" class="btn btn-outline-secondary"></button-->
                            </a>
                        </li>
                        <!-- style="margin:2pt; padding:6pt;" -->
                        <li class="active">
                            <a class="nav-link" type="button" href="https://lnsp-cg.org/enregistre.php" class="btn btn-outline-secondary">
                                SE PRE-ENRENGISTRER
                                 <!--<button  class="btn btn-outline-secondary"></button -->
                            </a>
                        </li>
                        
                        <!-- 
                        <li class="active">
                            <a style="margin:2pt; padding:6pt;" class="nav-link" href="./">
                                NOS SERVICES
                                button type="button" class="btn btn-outline-secondary"></button
                            </a>
                        </li>
                        <li class="active">
                            <a style="margin:2pt; padding:6pt;" class="nav-link" href="./">
                                NOS PROJETS
                                button type="button" class="btn btn-outline-secondary"></button
                            </a>
                        </li>
                        <li class="active">
                            <a style="margin:2pt; padding:6pt;" class="nav-link" href="./">
                                BIBLIOTHEQUE
                                button type="button" class="btn btn-outline-secondary"></button
                            </a>
                        </li> style="margin:2pt; padding:6pt;" -->
                        <li class="active" style=" background: white;">
                            <a class="nav-link blink_me" href="./ncontact.php">
                                
                                <button type="button" class="btn btn-outline-secondary">NOUS CONTACTER</button>
                            </a>

                        </li>
                        <!-- style="margin:2pt; padding:6pt;" -->
                        <li class="active">
                            <a  class="nav-link"
                                href="https://lnsp-cg.org/session_in.php">
                                
                                <button type="button" class="btn btn-outline-success">SE CONNECTER</button>
                            </a>

                        </li>

                    </ul>

                </div>
            </div>
        </nav>
        <!-- Image and text -->

        <!-- Navigation -->

        
        <div style="height:3pt; background: #ffde00;">
        </div>
    </header><br/><br/><html>
      <head>
      <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
      <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
      <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
      <!------ Include the above in your HEAD tag ---------->

      <style>
        body {
            background:#333;
        }
        #login {
          -webkit-perspective: 1000px;
          -moz-perspective: 1000px;
          perspective: 1000px;
          margin-top:10pt;
          margin:auto;
        }
        .login {
          font-family: 'Josefin Sans', sans-serif;
          -webkit-transition: .3s;
          -moz-transition: .3s;
          transition: .3s;
          -webkit-transform: rotateY(40deg);
          -moz-transform: rotateY(40deg);
          transform: rotateY(40deg);
        }
        .login:hover {
          -webkit-transform: rotate(0);
          -moz-transform: rotate(0);
          transform: rotate(0);
        }
        .login article {
          
        }
        .login .form-group {
          margin-bottom:17px;
        }
        .login .form-control,
        .login .btn {
          border-radius:0;
        }
        .login .btn {
          text-transform:uppercase;
          letter-spacing:3px;
        }
        .input-group-addon {
          border-radius:0;
          color:#fff;
          background:#f3aa0c;
          border:#f3aa0c;
        }
        .forgot {
          font-size:16px;
        }
        .forgot a {
          color:#333;
        }
        .forgot a:hover {
          color:#5cb85c;
        }

        #inner-wrapper, #contact-us .contact-form, #contact-us .our-address {
            color: #1d1d1d;
            font-size: 19px;
            line-height: 1.7em;
            font-weight: 300;
            padding: 50px;
            background: #fff;
            box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.16), 0 2px 10px 0 rgba(0, 0, 0, 0.12);
            margin-bottom: 100px;
        }
        .input-group-addon {
            border-radius: 0;
                border-top-right-radius: 0px;
                border-bottom-right-radius: 0px;
            color: #fff;
            background: #f3aa0c;
            border: #f3aa0c;
                border-right-color: rgb(243, 170, 12);
                border-right-style: none;
                border-right-width: medium;
        }
      </style>
    
    </head>
<body>
        
          <div class="col-md-4 " id="login">
						<section id="inner-wrapper" class="login">
              <span><strong>VOTRE MESSAGE</strong></spam>
							<article>
								<form  action ="listsuggest.php" method = "POST" >
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon"><i class="fa fa-user"> </i></span>
											<input type="text" class="form-control" name ="nompr" placeholder="Nom et prénom" required>
										</div>
									</div>
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon"><i class="fa fa-envelope"> </i></span>
											<input type="email" class="form-control" name ="vemail" placeholder="Votre émail" required>
										</div>
									</div>
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon"><i class="fa fa-key"> </i></span>
											<input type="text" class="form-control" name ="vobjet" placeholder="Objet:" required>
										</div>
									</div>
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon"><i class="fa fa-key"> </i></span>
											<textarea type="textarea" class="form-control" name ="vmassager" placeholder="Votre text c'est ici" required></textarea>
										</div>
									</div>
									  <button type="submit" class="btn btn-success btn-block">Envoyer</button>
									  <button type="reset" class="btn btn-block">Annuler</button>
								</form>
							</article>
						</section>
          </div>

        


    <script>
      // Fonction executée lors de l'utilisation du clic droit.
      $(document).bind("contextmenu",function() {
        alert('Merci de respecter le contenu en ne pas le copier sans autorisation!');
        return false;
      });
    </script>
</body>

    <footer class=" py-2 bg-dark"> <!--- fixed-bottom -->
      <div style="height:2pt; background: #ffde00;"> </div>
      <div>
          <p class="m-0 text-center text-white fixed-down">
            Copyright &copy; Laboratoire National de Santé Publique 2021
          </p>
      </div>

    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script>
      // Fonction executée lors de l'utilisation du clic droit.
      $(document).bind("contextmenu",function()
      {
      alert('Merci de respecter le contenu en ne pas le copier sans autorisation!');
      return false;
      });
    </script>

</body></hmtl>