
<!DOCTYPE html>
<html lang="fr">

<head>
    <title>LNSP-CG</title>
        <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script> -->


    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css"
        integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>

    <link href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/js/select2.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css" rel="stylesheet" />



    <link rel="shortcut icon" href="images/republic-of-the-congo.svg" />

    <link rel="stylesheet" href="cssmenu.css">

    <style>
    .blink_me {
        background: rgba(11, 42, 155, 0.124);
        animation: blinker 2s linear infinite;
    }

    @keyframes blinker {
        65% {
            opacity: 0.52;
        }
    }

    @media screen and (max-width: 600px) {

        .sidebar-brand-text,
        #xname {
            display: none;
        }

        #xmenu {
            float: right;
        }
    }

    @media screen and (min-width: 600px) {
        .navbar-brand {
            font-size: 10px;
        }

        #zname {
            display: none;
        }

    }
    </style>
    <script type="text/javascript">
    window.$crisp = [];
    window.CRISP_WEBSITE_ID = "286073c0-a54f-4930-92cc-20a0de5c53b5";
    (function() {
        d = document;
        s = d.createElement("script");
        s.src = "https://client.crisp.chat/l.js";
        s.async = 1;
        d.getElementsByTagName("head")[0].appendChild(s);
    })();
    </script>
</head>

<body>
    <header>
        <nav class="navbar navbar-light bg-light">
            <div class="navbar navbar-inverse navbar-fixed-top bs-docs-nav" role="banner">
                <a class="navbar-brand" href="#">
                    <h3 class="text-center text-white bg-dark font-weight-bold fixed-top">
                        <img src="images/republic-of-the-congo.svg" width="60" height="45" alt="Drapeau Congolais" />
                        <spam>
                            <a id="xname" href="#" style="color: #ffffff;">LABORATOIRE NATIONAL DE SANTE PUBLIQUE</a>
                            <a id="zname" href="#" style="color: #ffffff;">LNSP - CONGO</a>
                        </spam>

                    </h3>
                </a>
            </div>
        </nav>

        <div style="height:12pt; background: #e70000;">

        </div>
        <nav style="background: #e700F0;"
            class="navbar navbar-expand-lg shadow-lg navbar-dark h7 text-center bg-dark fixed-relative navbar-fixed-top">
            <div id="xmenu" class="" style=" margin:auto;" role="banner">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive"
                    aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse justify-content-center navbar-inverse bs-docs-nav"
                    id="navbarResponsive" style="margin:0pt; padding:8pt;">

                    <ul class="nav-item navbar-nav ">

                        <!-- style="margin:2pt; padding:6pt;" -->
                        <li class="active">
                            <a class="nav-link" role="button" href="https://lnsp-cg.org/ncov2" class="btn btn-outline-warning">
                                VOTRE RESULTAT ICI
                                <!--<button type="button" class="btn btn-outline-warning"></button -->
                            </a>
                        </li>
                        <!-- style="margin:2pt; padding:6pt;" -->
                        <li class="active">
                            <a class="nav-link" href="https://lnsp-cg.org/testantigene.php" >
                                TESTS-ANTIGENIQUES
                                <!--<button type="button" class="btn btn-outline-secondary"></button-->
                            </a>
                        </li>
                        <!-- style="margin:2pt; padding:6pt;" -->
                        <li class="active">
                            <a class="nav-link" type="button" href="https://lnsp-cg.org/enregistre.php" class="btn btn-outline-secondary">
                                SE PRE-ENRENGISTRER
                                 <!--<button  class="btn btn-outline-secondary"></button -->
                            </a>
                        </li>
                        
                        <!-- 
                        <li class="active">
                            <a style="margin:2pt; padding:6pt;" class="nav-link" href="./">
                                NOS SERVICES
                                button type="button" class="btn btn-outline-secondary"></button
                            </a>
                        </li>
                        <li class="active">
                            <a style="margin:2pt; padding:6pt;" class="nav-link" href="./">
                                NOS PROJETS
                                button type="button" class="btn btn-outline-secondary"></button
                            </a>
                        </li>
                        <li class="active">
                            <a style="margin:2pt; padding:6pt;" class="nav-link" href="./">
                                BIBLIOTHEQUE
                                button type="button" class="btn btn-outline-secondary"></button
                            </a>
                        </li> style="margin:2pt; padding:6pt;" -->
                        <li class="active" style=" background: white;">
                            <a class="nav-link blink_me" href="./ncontact.php">
                                
                                <button type="button" class="btn btn-outline-secondary">NOUS CONTACTER</button>
                            </a>

                        </li>
                        <!-- style="margin:2pt; padding:6pt;" -->
                        <li class="active">
                            <a  class="nav-link"
                                href="https://lnsp-cg.org/session_in.php">
                                
                                <button type="button" class="btn btn-outline-success">SE CONNECTER</button>
                            </a>

                        </li>

                    </ul>

                </div>
            </div>
        </nav>
        <!-- Image and text -->

        <!-- Navigation -->

                <main role="main">
            <div id="myCarousel" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                    <li data-target="#myCarousel" data-slide-to="1"></li>
                    <li data-target="#myCarousel" data-slide-to="2"></li>
                    <li data-target="#myCarousel" data-slide-to="3"></li>
                    <li data-target="#myCarousel" data-slide-to="4"></li>
                    <li data-target="#myCarousel" data-slide-to="5"></li>
                </ol>
                <div class="carousel-inner">
                    <div class="carousel-item active">
                        <img src="images/lnsptoucher.jpg" style="width: 100%;" alt="">
                        <div class="container">
                            <div class="carousel-caption text-left">
                                <h1>LNSP Congo</h1>
                                <p>Tout savoir sur le LNSP</p>
                                <p><a class="btn btn-lg btn-success" href="#" role="button">Actualités</a></p>
                            </div>
                        </div>
                    </div>

                    <div class="carousel-item">
                        <img src="images/lnspArrier.jpg" style="width: 100%;" alt="">
                        <div class="container">
                            <div class="carousel-caption text-left">
                                <h1>LNSP Congo</h1>
                                <p>Tout savoir sur le LNSP</p>
                                <p><a class="btn btn-lg btn-success" href="#" role="button">Actualités</a></p>
                            </div>
                        </div>
                    </div>

                    <div class="carousel-item">
                        <img src="images/labo1.jpg" style="width: 100%;" alt="">
                        <div class="container">
                            <div class="carousel-caption">
                                <h1>Le LNSP, vu de nuit</h1>
                                <p>---------</p>
                                <p><a class="btn btn-lg btn-primary" href="./pagedg.php" role="button">Le mot du
                                        Directeur Général du LNSP</a></p>
                                <p><a class="btn btn-lg btn-primary" href="http://sante.gouv.cg/" role="button">Le
                                        ministère de la santé</a></p>
                            </div>
                        </div>
                    </div>

                    <div class="carousel-item">
                        <img src="images/labo.jpg" style="width: 100%;" alt="">
                        <div class="container">
                            <div class="carousel-caption text-left">
                                <h1>Le diagnostic de la COVID-19 au Congo</h1>
                                <p>Les examens virologiques déterminent si l'on porte le virus en soit ou non</p>
                                <p><a class="btn btn-lg btn-success" href="#" role="button">Examen PCR</a></p>
                            </div>
                        </div>
                    </div>
                </div>

                <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">En arrière</span>
                </a>
                <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">En avant</span>
                </a>
            </div>
        </main>

        
        <div style="height:3pt; background: #ffde00;">
        </div>
    </header>
<div class="container">

    <div class="row">

        <div class="col-lg-3">

            <h5 class="card-header my-2 text-center text-success  navbar-inverse">
                <a href="https://lnsp-cg.org/enregistre.php">SE PRE-ENRENGISTRER</a>
            </h5>
            <h5 class="card-header my-2 text-center text-success  navbar-inverse">
                <a href="https://lnsp-cg.org/ncov2">CONSULTER VOTRE RESULTAT</a>
            </h5>
            <div class="list-group">
                <!-- <a href="https://lnsp-cg.org/ncov2" class="list-group-item text-white navbar-inverse">COVID-19</a>
                <a href="#" class="list-group-item text-muted bg-light">Goutte épaisse</a>
                <a href="#" class="list-group-item text-muted bg-light">ECBU</a> -->

                <div class="list-group-item text-muted bg-light">
                    <div class="image" style="text-align:center; font-size:10pt;">
                        <img src="images/madame.jpg" width="210" height="152" alt="DG pi, LNSP du Congo" />
                        <strong>GILBERT MOKOKI</strong><br />
                    </div>

                    <span>
                        <P style="text-align:center; font-size:12pt;">
                            Ministre de la Santé et de la Population
                        </P>
                    </span>

                </div>

                <div class="list-group-item text-muted bg-light">
                    <div class="image"><img src="images/rfniama.jpg" width="215" height="165" alt="DG pi, LNSP du Congo" /></div>
                    <p size="8pt" style="text-align:center;/*text-align:justify;*/ font-size:10pt;">
                        <i></i>
                        Le Directeur Général du Laboratoire National de Santé Publique,
                        entend mettre les bouchers doubles afin de redorer le blason de ce Laboratoire,
                        surtout en cette période de crise sanitaire dominée par la pandémie de la COVID-19.
                        « Les circonstances dans lesquelles nous sommes portés à la tête de cet établissement témoignent
                        de l’urgence avec laquelle nous devons agir, compte tenu de l’impact de cette pandémie dans le
                        pays. Pour ce faire, nous devons associer toutes les compétences dont dispose notre structure
                        commune, tant du point de vue des ressources humaines que techniques. Ceci dans le but de rendre
                        à bref
                        échéance notre laboratoire attractif et compétitif en termes de qualité de nos prestations et de
                        l’étendue de son offre.
                        Pour y parvenir, nous ne ménagerons aucun effort ».
                        <br />
                        <strong>Pr. Roch Fabien NIAMA.</strong>



                    </p>
                </div>
            </div>

        </div>
        <!-- -------------------------------------------------------Activité de dernière munite---------------------------------------------------------------->

        <div class="col-lg-9">
            <div>
                <h5 class="card-header my-2 text-center text-success">
                    <marquee behavior="alternate">
                        <span style="padding-top:52pt; color:rgb(8, 8, 8);font-size:18pt;text-align:center; /*text-transform: uppercase;*/">
                            <!-- Ce site est en construction, merci de revenir nous visiter ! -->
                        </span>
                    </marquee>
                </h5>
            </div>

            <div id="carouselExampleIndicators" class="carousel slide my-4" data-ride="carousel">
            </div>

            <div class="row">

                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card h-100">
                        <a href="https://lnsp-cg.org/ncov2">
                            <div class="image"><img class="card-img-top" src="images/testcovid.jpg" alt="">
                        </a>
                    </div></a>
                    <div class="card-body">
                        <h4 class="card-title">
                            <a href="https://lnsp-cg.org/ncov2">Résultats PCR sans se déplacer</rendez-vous></a>
                        </h4>
                        <p class="card-text">Il est désormais possible de consulter vos résultats COVID-19 depuis chez
                            vous.</p>
                    </div>
                    <div class="card-footer">
                        <span class="text-dark"><a href="#">En savoir plus</a></span>
                    </div>
                </div>
            </div>




            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100">
                    <a href="#">
                        <div class="image"><img class="card-img-top" src="masq.jpg" alt="">
                    </a>
                </div>
                <div class="card-body">
                    <h4 class="card-title">
                        <a href="#">Les Gestes barrières</a>
                    </h4>
                    <p class="card-text">
                        Les gestes barrières sont pour l'heure actuelle, le meilleur moyen de se protéger et de protéger
                        les autres contre la Covid-19
                    </p>

                </div>
                <div class="card-footer">
                    <span class="text-dark"><a>En savoir plus</a></span>
                </div>
            </div>
        </div>

        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card h-100">
                <a href="#">
                    <div class="image"><img class="card-img-top" src="masq.jpg" alt="">
                </a>
            </div>
            <div class="card-body">
                <h4 class="card-title">
                    <a href="#">Les sites de dépistage volontaire</a>
                </h4>
                <p class="card-text">Se dépister, c'est protéger sa famille contre la Covid-19</p>
            </div>
            <div class="card-footer">
                <span class="text-dark"><a href="#">En savoir plus</a></span>
            </div>
        </div>
    </div>
</div>
<!-- ---------------------------FIN----------------------------Activité de dernière munite---------------------------------------------------------------->

<div class="container card-header my-1 text-center text-success">

    <div class="container-fluid">

        <!-- Page Heading -->
        <!-- <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h4 mb-0 text-gray-800">
                <strong>INDICATEURS CLES DE LA COVID-19 A LA DATE DU :
                    mercredi 07 d�cembre 2022                </strong>
            </h1>

            <a href="sitrep/SITREP N 102-COVID-19-CONGO-26-09-2020.pdf"
                class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
                <i class="fas fa-download fa-sm text-white-50"></i>
                SITREP DE LA COVID-19 AU CONGO N°102 DU 26 SEPT. 2020
                
            </a>

        </div> -->

        <!-- LEONCE STAT COVID --------->
        <!-- <div class="row">



            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-info shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Depuis le 14 mars
                                    2020:</div>
                                <div class="mb-0 text-gray-800"> CAS
                                    CONFIRMES</div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-info-circle fa-2x text-300" style="color: #0099cc;"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-success shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-success text-uppercase mb-1">CAS GUERIS</div>
                                <div class="mb-0 text-gray-800">
                                                                    </div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-medkit fa-2x  text-300" style="color: #20c997;"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-danger shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">DECEDES</div>
                                <div class="mb-0 text-gray-800"> DECES CAS
                                    POSITIFS</div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-minus-square fa-2x text-300" style="color: #ff6b6b;"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3 col-md-6 mb-4">
                <div class="card border-left-warning shadow h-100 py-2">
                    <div class="card-body">
                        <div class="row no-gutters align-items-center">
                            <div class="col mr-2">
                                <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">CAS ACTIFS</div>
                                <div class="mb-0 text-gray-800"> CAS SONT
                                    EN
                                    COURS DE SUIVI</div>
                            </div>
                            <div class="col-auto">
                                <i class="fas fa-heartbeat fa-2x text-300" style="color: #ff922b;"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div> -->


    </div>

</div>
</div>


</div>


</div>


<div class="container">
    <h5 class="card-header my-1 text-center text-success">
        <marquee behavior="alternate">
            <span name="textconstruction" style="padding-top:52pt; color:rgb(8, 8, 8);font-size:18pt;text-align:center; text-transform: uppercase;">
                <!-- Ce site est en construction, merci de revenir nous visiter ! -->
            </span>
        </marquee>
    </h5>
</div>

<script async src='https://stackwhats.com/pixel/eaf36d8805b79019d236c89087e1a6'></script>

    <footer class=" py-2 bg-dark"> <!--- fixed-bottom -->
      <div style="height:2pt; background: #ffde00;"> </div>
      <div>
          <p class="m-0 text-center text-white fixed-down">
            Copyright &copy; Laboratoire National de Santé Publique 2021
          </p>
      </div>

    </footer>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script>
      // Fonction executée lors de l'utilisation du clic droit.
      $(document).bind("contextmenu",function()
      {
      alert('Merci de respecter le contenu en ne pas le copier sans autorisation!');
      return false;
      });
    </script>

</body><!--
  Le nouveau Directeur Général par intérim, entend mettre les bouchers doubles afin de redorer le blason du Laboratoire National de Santé Publique, surtout en cette période de crise sanitaire dominée par la propagation de la pandémie du COVID-19. « Les circonstances dans lesquelles, que nous sommes portés à la tête de cet établissement. Le pays et tout comme le monde traverse une des crises les plus importantes de son histoire, aucune crise n’avait encore jamais entrainé le confinement de près de 3 milliards de personnes à travers le monde, c’est pour vous dire la gravité du moment, nous n’avons pas mission ici, de mener la chasse aux sorcières. Nous ne venons pas pour régler un compte à qui que ce soit au contraire, les autorités nous ont dit de contribuer, de nous mettre sur la dynamique de nos prédécesseurs de manière à faire en sorte que le laboratoire puisse se mettre au niveau sinon, plus que les meilleurs laboratoires de notre sous-région ou encore que les meilleurs laboratoires de biologie médicale et de recherches et notre énergie va être consacré à cela », a déclaré le Pr Roch Flavien NIAMA.
-->

</html>