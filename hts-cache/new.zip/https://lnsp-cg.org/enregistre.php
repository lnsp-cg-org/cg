

<!DOCTYPE html>
<html>
<head>
	<title>Enregistrer</title>    
	<meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta content="IE=Edge" http-equiv="X-UA-Compatible" />
    <link rel="shortcut icon" href="https://lnsp-cg.org/images/republic-of-the-congo.svg" />

    <!-- <link href="https://lnsp-cg.org/pev/into/css/landing.css" media="screen" rel="stylesheet" type="text/css" /> -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous">
    </script>

    <link href='https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css'>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>

</head>
<body style="margin: 8px; text-align: center; background-color: #282828; " class="border border-danger" nselectstart="return false" oncontextmenu="return false" ondragstart="return false">
	<style type="text/css">
		
        .page1 {
            /* width: 24cm; */
            min-height: 1cm;
            padding: 0.268cm;
            margin: 0.31cm;

            border-radius: 5px;
            box-shadow: 0 0 7px rgba(20, 0, 0, 120.31);

        }

        .encadre {

            background-color: rgba(255, 255, 255);
            margin: 0.451%;
        }
	</style>
	<div style="margin: auto; text-align: justify-all;">
            <div class="page1" style="text-align: center; ">
                <div style="height:4.0cm;margin: auto;text-align: center; ">
                    <div class="encadre">
                        <table border="0" style="margin: auto;text-align: center; ">
                            <tr>
                                <td style="text-align: right; width:10%;" style=" border: 1.6px solid rgba(55, 55, 215);">
                                    <img src="https://lnsp-cg.org/images/drapo242.jpg" width="40" />
                                </td>
                                <td style="width:120%;">
                                    <span class="pays" style="text-align: left;text-align: center; ">
                                        <b>REPUBLIQUE DU CONGO</b>
                                        <div style="text-align: center; color: #000000; font-size:13px; border-bottom: thick double #26650E;">
                                            <span>
                                                Ministère de la Santé et de la Population

                                            </span>

                                        </div>

                                    </span>

                                    <div style="font-size:16px; font-weight: bold; padding-right:4%; padding-left:4%; ">
					                   COMITE TECHNIQUE DE RIPOSTE A LA PANDEMIE DE COVID1-9<br/>
                                        
                                    </div>

                                </td>
                                <td style="text-align: right; width:10%;" style=" border: 1.6px solid rgba(55, 55, 215);">
                                    <img src="https://lnsp-cg.org/images/armoirieRC.png" width="40" />
                                </td>
                            </tr>
                        </table>

                    </div>
			        <hr style="border:2px solid white"/>
                        <!-- span style="color:white;>DEPISTAGE ET VACCINATION CONTRE LA COVID19</span -->

                </div>
            </div>


	    <div style="text-align: center; color: white; border-bottom: 2px solid #aaaeee; ">
            <h3>FORMULAIRES DE <br/>PRE-ENREGISTREMENT  </h3>
            <!--pour le test de dépistage de la Covid et à vaccination-->
        </div>

        <hr>
        <br>

		<div style="margin-left: 2%; margin-bottom: 4%; margin-top: 2%;">
			<a role="button" class="btn btn-success" href="https://lnsp-cg.org/testpcr.php">
				<span style=" padding: auto; height: 150px;">Se pré-enregistrer pour le TEST-PCR <br/> Covid pour tous les laboratoires autorisés.</span>
			</a>
		</div>


		<div style="margin-left: 2%; margin-bottom: 3%; margin-top: 3%;">
			<a role="button" class="btn btn-success" href="https://lnsp-cg.org/testantigene.php">
				<span style=" padding: auto; height: 150px;">
					Enregistrement des données test-antigéniques
				</span>
			</a>
		</div>

        <div style="margin-left: 2%;margin-top: 4%;margin-bottom: 3%;">
            <a role="button" class="btn btn-warning" href="https://pevcongo.site/pev/into/enregistrement.php">
                <span style=" padding: auto; height: 150px;" >Se pré-enregistrer pour la  <br/> VACCINATION contre la covid-19.</span>
            </a>
        </div>
	</div>


</body>
</html>